'''
Created on 23-Jul-2020
@author: jaspreet
'''
DATASHEET = "DataSheet"
TESTCASESHEET = "TestCase"
KEYWORDSHEET = "Keyword"

TCID = "TCID"
RUNMODE = "RunMode"
KEYWORD = "Keyword"
OBJECT = "Object"
DATA = "Data"

RUNMODE_YES = "Y"
RUNMODE_NO = "N"

TEST_RESOURCES = "D:\\eclipse\\HybridFramework\\testResources\\"
XLS_PATH = TEST_RESOURCES+"hybridR.xlsx"

CHROME='Chrome'
FIREFOX='Firefox'
EDGE='Edge'
IE='IE'

Y='Y'
N='N'