from selenium import webdriver

driver = webdriver.Edge(executable_path="C:\Webdriver\msedgedriver.exe")
