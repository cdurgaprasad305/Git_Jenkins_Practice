#no profiling
#options
from selenium import webdriver

driver = webdriver.Ie()