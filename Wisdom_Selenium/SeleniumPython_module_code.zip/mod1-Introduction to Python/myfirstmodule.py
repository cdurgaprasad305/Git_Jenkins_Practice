#blank spaces - IndentationError error
#EOL
#Python is an interpreted language
from _datetime import datetime

print("This is my first code in pycharm")
print("Modules should have short, all-lowercase names. Underscores can be used in the module name if it improves \
readability. Python packages")
