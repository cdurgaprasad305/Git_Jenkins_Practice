a = 10
b = 3
print("Total of a and b : "+str(a+b))
