import selenium


def test_selenium():
    print(selenium.__version__)
