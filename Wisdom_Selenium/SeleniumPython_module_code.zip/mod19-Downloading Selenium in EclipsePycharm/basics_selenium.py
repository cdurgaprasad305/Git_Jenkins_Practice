import selenium

print(selenium.__version__)