a = 3
if(a<10):  #condition is satisfied = boolean True
    # condition is not satisfied = boolean False
    print("a is less than 10")