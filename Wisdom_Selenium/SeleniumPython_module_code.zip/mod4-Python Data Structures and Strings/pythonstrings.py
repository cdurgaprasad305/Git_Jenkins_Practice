var = "Jaspreet"
print(type(var))

a = 'cat' #c = 0, a = 1, t = 2
print(type(a))
print(len(a))
print(a)

# a[0] = 'm'
# print(a)
a = 'mat'
print(a)

