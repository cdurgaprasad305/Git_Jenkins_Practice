set1 = {1,1,50,5.5,99,99,99,'Apple', 'Mango'}
print(set1)
print(type(set1))
print(len(set1))

set1.add("yellow")
print(set1)
print(len(set1))
