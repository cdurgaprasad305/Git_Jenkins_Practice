tuple1 = (1,525, 5.4,'apple')
print(len(tuple1))
print(type(tuple1))

tuple1 = tuple1+(4, "Black", 5.5)
print(tuple1)

# tuple1[3]="Apple"
# print(tuple1)

del tuple1
print(tuple1)