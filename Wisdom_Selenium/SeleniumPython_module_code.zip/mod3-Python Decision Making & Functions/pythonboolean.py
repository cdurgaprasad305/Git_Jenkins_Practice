a = 3
if(a>10):
    print("a is less than 10")
