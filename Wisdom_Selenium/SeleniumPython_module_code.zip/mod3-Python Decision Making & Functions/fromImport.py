#from - where
#import - what

from mod3.functionDemo import sum1, sum4


sum1()
print(sum4())