var = 0
while(var<=10):
    var = var+1
    if(var==5):
        continue
    print(var)

for i in range(10, 50):
    pass
    # if(i==13):
    #     continue
    # print(i)

#break : breaks the whole code after break keyword
#continue : skip specific condition

