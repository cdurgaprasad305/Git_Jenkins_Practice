'''
Created on 16-Mar-2020
@author: jaspreet
'''
class laptop:
    def processor(self):
        print("I am in processor fuction")
        
    def graphicCard(self):
        print("I am in graphic card function")
        
    def camera(self):
        print("I am in camera function")
        
l = laptop()
l.camera()