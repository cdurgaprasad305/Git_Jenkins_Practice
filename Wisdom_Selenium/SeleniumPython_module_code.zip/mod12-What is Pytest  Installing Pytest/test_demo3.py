class TestDemo:
    def test_demo(self):
        print("Demonstrating test class functionality.....")