def test_demo2():
    print("Creating second test in second module")