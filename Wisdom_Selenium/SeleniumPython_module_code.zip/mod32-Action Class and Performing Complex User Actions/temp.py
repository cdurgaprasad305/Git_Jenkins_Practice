'''
Created on 07-May-2020
@author: jaspreet
'''

from random import randint

a = randint(0,10)
print(a)
