# you may use same variable
# variable are container whose value may vary or may not

a=9.5
print(a)
print(type(a))

a='python'
print(a)
print(type(a))
'''
#name should not start wth no. - invalid syntax
#name can contain a no. - possible
#special symbol '_'- possible
#special symbol - $!@ - SyntaxError
#you cannot use keyword as a variable
'''

a1 = 10
print(a1)
print(type(a1))
#keywords : if, else, elif, for , while, try, catch , finally
var_1 = 'variable 1'
print(type(var_1))
print(var_1)

c = 5+7j
print(type(c))
d = 8+4j
result = c+d
print(result)
print(type(result))
