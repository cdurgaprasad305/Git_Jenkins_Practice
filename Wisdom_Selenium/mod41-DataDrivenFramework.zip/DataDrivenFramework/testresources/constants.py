'''
Created on 08-Jul-2020
@author: jaspreet
'''

TESTSHEET = "TestCases"
DATASHEET = "DataSheet"
TEST_RESOURCES = "D:\\Jaspreet\\code_pycharm\\eclipse\\DataDrivenFramework\\testresources\\"
XLS_FILE_PATH = TEST_RESOURCES+"DDF.xlsx"

TCID_COL = "TCID"
RUNMODE_COL = "RunMode"
RUNMODE_YES = "Y"
RUNMODE_NO = "N"
BROWSER="BrowserName"
USERNAME="Username"
PASSWORD="Password"
COMPANY_NAME="CompanyName"
FIRSTNAME="FirstName"
LASTNAME="LastName"
EXPECTED_RESULT="ExpectedResult"
EXPECTED_SUCCESS="Success"
EXPECTED_FAILURE="Failure"
LEADNAME="LeadName"
DEALNAME="DealName"
CLOSING_DATE="ClosingDate"
ACCOUNTNAME="AccountName"
STAGE="Stage"

CHROME='Chrome'
FIREFOX='FireFox'
EDGE='Edge'
IE='IE'
