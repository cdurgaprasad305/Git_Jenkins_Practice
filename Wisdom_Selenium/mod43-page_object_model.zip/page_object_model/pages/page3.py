class page3:
    def __init__(self, a):
        self.a = a

    def page3(self):
        print("in page 3")
        print(self.a)
