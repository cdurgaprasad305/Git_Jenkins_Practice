TESTRESOURCES = "D:\\Jaspreet\\PycharmProjects\\page_object_model\\testresources\\"
ENVIRONMENT_PROPERTIES = TESTRESOURCES+"environment.properties"
XLS_FILEPATH = TESTRESOURCES+"pageobjectmodel.xlsx"

TESTSHEET = "Testcase"
DATASHEET = "Datasheet"

TCID = "TCID"
RUNMODE = "Runmode"
RUNMODE_Y = "Y"
RUNMODE_N = "N"
BROWSERNAME = "Browsername"
USERNAME = "Username"
PASSWORD = "Password"

CHROME = "Chrome"
FIREFOX = "Firefox"
EDGE = "Edge"
IE = "IE"

GRIDRUN_Y = 'Y'
GRIDRUN_N = 'N'