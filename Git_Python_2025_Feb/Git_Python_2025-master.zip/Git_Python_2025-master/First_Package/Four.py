def four():
    print("Inside four (), Function Message from Four.py file from First_Package")


print("Message from Four.py -- Outside function")


def test_on1():
    print("---Simple example----")
    # assert False
import time
time.sleep(3)
