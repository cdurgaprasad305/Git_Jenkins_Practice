print("--Welcome Durga-- from First_Package __init__.py File")

a = 10
b = 20
url = "https://www.google.com"
