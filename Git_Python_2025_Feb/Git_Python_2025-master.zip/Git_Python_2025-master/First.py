
def add1():
    a=10
    b=20
    print("The sum of two numbers: " +str(a+b))

def sub1():
        a = 10
        b = 20
        print("The Sub of two numbers: " + str(a - b))

def mult1():
            a = 10
            b = 20
            print("The Product of two numbers: " + str(a * b))


# add1()
sub1()
mult1()

def test_first_add1():
    add1()
    return

# Simple comment line adding from git hub to test
# Simple line of command adding from local pycharm IDE

# Practice Push and pull in GIT